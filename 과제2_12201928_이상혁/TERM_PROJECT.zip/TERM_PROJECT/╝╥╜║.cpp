#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <ctime>
#include <cmath>
#include <queue>
#include <unordered_set>

using namespace std;

#define INF 999999

struct Individual {
    vector<int> chromosome;
    double fitness;

    bool operator<(const Individual& ind) const {
        return fitness < ind.fitness;
    }
};

// ���յ� ���
double calculateFitness(Individual& ind, vector<pair<int, int>> graph[], int start, int goal) {
    double fitness = 0.0;
    int current = start;
    unordered_set<int> visited;
    visited.insert(current);

    for (int node : ind.chromosome) {
        if (current == goal) break;
        bool found = false;
        for (auto& edge : graph[current]) {
            if (edge.first == node) {
                fitness += edge.second;
                current = node;
                found = true;
                break;
            }
        }
        if (!found || visited.count(current)) {
            fitness = INF;
            break;
        }
        visited.insert(current);
    }

    if (current != goal) fitness = INF;
    ind.fitness = fitness;
    return fitness;
}

// �ʱ� ���� ����
vector<Individual> createPopulation(int populationSize, int chromosomeLength, int N, int start, int goal, vector<pair<int, int>> graph[]) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0, N - 1);

    vector<Individual> population;

    while (population.size() < populationSize) {
        int current = start;
        unordered_set<int> visited;
        visited.insert(current);

        Individual ind;

        while (ind.chromosome.size() < chromosomeLength && current != goal) {
            vector<int> neighbors;
            for (auto& edge : graph[current]) {
                if (edge.first != start && visited.count(edge.first) == 0) {
                    neighbors.push_back(edge.first);
                }
            }

            if (neighbors.empty()) break;

            int next = neighbors[dis(gen) % neighbors.size()];
            ind.chromosome.push_back(next);
            current = next;
            visited.insert(current);
        }

        if (current == goal) {
            ind.fitness = INF;
            population.push_back(ind);
        }
    }

    return population;
}

// ����
vector<Individual> selection(const vector<Individual>& population) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0, population.size() - 1);
    vector<Individual> parents;
    for (int i = 0; i < population.size(); ++i) {
        int idx1 = dis(gen);
        int idx2 = dis(gen);
        if (population[idx1].fitness < population[idx2].fitness) {
            parents.push_back(population[idx1]);
        }
        else {
            parents.push_back(population[idx2]);
        }
    }
    return parents;
}

// ����
Individual crossover(const Individual& parent1, const Individual& parent2, int start, int goal, vector<pair<int, int>> graph[]) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0, min(parent1.chromosome.size(), parent2.chromosome.size()) - 1);
    int crossoverPoint = dis(gen);

    unordered_set<int> visited;
    Individual offspring;

    int current = start;

    for (int i = 0; i < crossoverPoint && i < parent1.chromosome.size(); ++i) {
        offspring.chromosome.push_back(parent1.chromosome[i]);
        visited.insert(parent1.chromosome[i]);
        current = parent1.chromosome[i];
    }

    for (int i = crossoverPoint; i < parent2.chromosome.size(); ++i) {
        if (visited.count(parent2.chromosome[i]) == 0) {
            offspring.chromosome.push_back(parent2.chromosome[i]);
            current = parent2.chromosome[i];
            visited.insert(current);
        }
    }

    // Ensure offspring leads to goal
    if (current != goal) {
        for (auto& edge : graph[current]) {
            if (edge.first == goal) {
                offspring.chromosome.push_back(goal);
                break;
            }
        }
    }

    offspring.fitness = INF;
    return offspring;
}

// ����
void mutate(Individual& ind, int N, int start, int goal, vector<pair<int, int>> graph[]) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> disGene(0, ind.chromosome.size() - 1);
    uniform_int_distribution<> disNode(0, N - 1);

    int mutationPoint = disGene(gen);
    int current = (mutationPoint > 0) ? ind.chromosome[mutationPoint - 1] : start;

    unordered_set<int> visited(ind.chromosome.begin(), ind.chromosome.begin() + mutationPoint);

    vector<int> neighbors;
    for (auto& edge : graph[current]) {
        if (visited.count(edge.first) == 0) {
            neighbors.push_back(edge.first);
        }
    }

    if (!neighbors.empty()) {
        int mutationNode = neighbors[disNode(gen) % neighbors.size()];
        ind.chromosome[mutationPoint] = mutationNode;
    }

    ind.fitness = INF;
}

int main() {
    const int N = 8;
    vector<vector<int>> adjMatrix(N, vector<int>(N, INF));
    vector<pair<int, int>> graph[N];

    for (int i = 0; i < N; ++i) {
        adjMatrix[i][i] = 0;
    }

    adjMatrix[0][1] = 8;
    adjMatrix[0][2] = 9;
    adjMatrix[0][3] = 11;
    adjMatrix[1][4] = 10;
    adjMatrix[2][1] = 6;
    adjMatrix[2][3] = 3;
    adjMatrix[2][4] = 1;
    adjMatrix[3][5] = 8;
    adjMatrix[3][6] = 8;
    adjMatrix[4][7] = 2;
    adjMatrix[5][2] = 12;
    adjMatrix[5][7] = 5;
    adjMatrix[6][5] = 7;
    adjMatrix[7][6] = 4;

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (adjMatrix[i][j] != INF) {
                graph[i].push_back({ j, adjMatrix[i][j] });
            }
        }
    }

    int populationSize = 50;
    int chromosomeLength = 10;
    int generations = 100;
    double mutationRate = 0.1;
    int start = 0;
    int goal = 7;

    vector<Individual> population = createPopulation(populationSize, chromosomeLength, N, start, goal, graph);

    for (int generation = 0; generation < generations; ++generation) {
        for (auto& ind : population) {
            calculateFitness(ind, graph, start, goal);
        }

        sort(population.begin(), population.end());

        vector<Individual> nextGeneration;
        int eliteSize = populationSize * 0.1;
        for (int i = 0; i < eliteSize; ++i) {
            nextGeneration.push_back(population[i]);
        }

        vector<Individual> parents = selection(population);
        while (nextGeneration.size() < populationSize) {
            int parent1Index = rand() % parents.size();
            int parent2Index = rand() % parents.size();
            Individual offspring = crossover(parents[parent1Index], parents[parent2Index], start, goal, graph);
            nextGeneration.push_back(offspring);
        }

        for (int i = eliteSize; i < nextGeneration.size(); ++i) {
            if ((rand() / double(RAND_MAX)) < mutationRate) {
                mutate(nextGeneration[i], N, start, goal, graph);
            }
        }

        population = nextGeneration;
    }

    Individual bestSolution = *min_element(population.begin(), population.end());
    cout << "Best path fitness: " << bestSolution.fitness << endl;
    cout << "Best path: ";
    for (int node : bestSolution.chromosome) {
        cout << node << " ";
    }
    cout << endl;

    return 0;
}